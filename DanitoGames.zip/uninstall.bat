@echo off
reg delete "HKCU\Software\Classes\danitogames" /f >nul
echo ✅ Uninstalled protocol: danitogames://
